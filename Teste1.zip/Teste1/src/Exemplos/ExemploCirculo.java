package Exemplos;

import java.util.Scanner;

public class ExemploCirculo {
    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Raio: ");
        float raio = teclado.nextFloat();
        float area = 3.14f * (raio * raio);
        System.out.println("Área = " + area);

    }
}
