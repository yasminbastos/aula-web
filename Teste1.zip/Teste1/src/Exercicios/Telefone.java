package Exercicios;

import java.util.Scanner;

public class Telefone {
    public static void main(String[] args) {
        Scanner tel = new Scanner(System.in);
        double assinatura = 17.90;
        double chamadaloc = 0.04;
        double chamadacel = 0.20;
        double inter = 34.29;
        System.out.print("Quantos minutos teve de chamada local: ");
        int local = tel.nextInt();
        double nocha = local * chamadaloc;
        System.out.print("Quantos minutos teve de chamada celular: ");
        int celu = tel.nextInt();
        double nocelu = celu * chamadacel;
        double valort = nocelu+nocha+inter+assinatura;
        System.out.println("Assinatura: R$"+ assinatura);
        System.out.println("Chamada local: R$"+ nocha);
        System.out.println("Chamada para celular: R$"+ nocelu);
        System.out.println("Interurbano: R$"+ inter);
        System.out.println("Valor total: R$"+ valort);


    }
}