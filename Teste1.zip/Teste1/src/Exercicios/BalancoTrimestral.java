package Exercicios;

public class BalancoTrimestral {
    //Exercicio 1
    public static void main(String[] args){
        float gastosJaneiro = 15000;
        float gastosFevereiro = 23000;
        float gastosMarco = 17000;
        float gastosTrimestrais = gastosJaneiro + gastosFevereiro + gastosMarco;
        System.out.println("Gasto total trimestral: " + gastosTrimestrais);
        //Exercicio 2
        float mediaMensal = gastosTrimestrais/3;
        System.out.println("Média mensal: " + mediaMensal);

    }

}
