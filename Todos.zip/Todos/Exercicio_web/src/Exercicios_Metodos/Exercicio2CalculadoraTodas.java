package Exercicios_Metodos;

import java.util.Scanner;

public class Exercicio2CalculadoraTodas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Calculadora (todas as operações)");
        System.out.print("Digite o primeiro número: ");
        double a = sc.nextDouble();
        System.out.print("Digite o segundo número: ");
        double b = sc.nextDouble();

        System.out.println("Soma: " + (a + b));
        System.out.println("Subtração: " + (a - b));
        System.out.println("Multiplicação: " + (a * b));
        if (b != 0) {
            System.out.println("Divisão: " + (a / b));
        } else {
            System.out.println("Divisão: impossível (divisão por zero).");
        }

        sc.close();
    }
}
