package Exercicios_Metodos;

import java.util.Scanner;

public class Exercicio1IMC {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Cálculo do IMC ");
        System.out.print("Informe o peso em kg: ");
        double peso = sc.nextDouble();
        System.out.print("Informe a altura em metros: ");
        double altura = sc.nextDouble();

        double imc = peso / (altura * altura);

        String classificacao;
        if (imc < 18.5) classificacao = "Abaixo do peso";
        else if (imc < 25.0) classificacao = "Peso normal";
        else if (imc < 30.0) classificacao = "Sobrepeso";
        else if (imc < 35.0) classificacao = "Obesidade grau I";
        else if (imc < 40.0) classificacao = "Obesidade grau II";
        else classificacao = "Obesidade grau III";

        System.out.printf("Seu IMC é: %.2f\n", imc);
        System.out.println("Classificação: " + classificacao);

        sc.close();
    }
}
