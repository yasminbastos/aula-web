package Exercicios_While;

import java.util.Scanner;

public class Menor {
    public static void main(String[] args) {
    Scanner men = new Scanner(System.in);
    int z = 0;
    float Me = 0;
    int c = 0;
    while  (z<10) {
        System.out.print("Digite o número: ");
        float Nu = men.nextFloat();
        while (c < 1) {
            Me = Nu;
            c++;
        }
        if (Me >= Nu) {
            Me = Nu;
        }
        z++;
    }
    System.out.print("O menor número é: "+ Me);

    }
}
