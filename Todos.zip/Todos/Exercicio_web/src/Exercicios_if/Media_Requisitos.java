package Exercicios_if;

import java.util.Scanner;

public class Media_Requisitos {
    public static void main(String[] args) {
        Scanner mer = new Scanner(System.in);

        System.out.println("Digite a sua primeira nota: ");
        float Nota1 = mer.nextFloat();
        System.out.println("Digite a sua segunda nota: ");
        float Nota2 = mer.nextFloat();
        System.out.println("Digite a sua terceira nota: ");
        float Nota3 = mer.nextFloat();

        float medfinal = (Nota1 + Nota2 + Nota3) / 3;

        if (medfinal < 2) {
            System.out.println("Péssimo! Aluno Reprovado! Sua média foi " + medfinal);
        } else if (medfinal < 4) {
            System.out.println("Ruim! Aluno Reprovado! Sua média foi " + medfinal);
        } else if (medfinal < 6) {
            System.out.println("Regular! Aluno Reprovado! Sua média foi " + medfinal);
        } else if (medfinal < 8) {
            System.out.println("Bom! Aluno Aprovado! Sua média foi " + medfinal);
        } else if (medfinal < 9.5) {
            System.out.println("Ótimo! Aluno Aprovado! Sua média foi " + medfinal);
        } else {
            System.out.println("Excelente! Aluno Aprovado! Sua média foi " + medfinal);
        }
    }
}
