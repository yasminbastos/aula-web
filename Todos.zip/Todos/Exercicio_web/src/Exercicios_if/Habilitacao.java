package Exercicios_if;

import java.util.Scanner;

public class Habilitacao {
    public static void main(String[] args) {
        Scanner hal = new Scanner(System.in);
        System.out.print("Digite seu nome: ");
        String Nome = hal.next();
        System.out.print("Quantos anos você tem: ");
        int Idade = hal.nextInt();
        if (Idade>=18){
            System.out.println("Nome: "+ Nome);
            System.out.println("Idade: "+ Idade);
            System.out.println("Tem permissão para dirigir!");
        }
        else {
            System.out.println("Nome: "+ Nome);
            System.out.println("Idade: "+ Idade);
            System.out.println("Não tem permissão para dirigir!");
        }
    }
}
