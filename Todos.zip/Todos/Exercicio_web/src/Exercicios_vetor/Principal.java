package Exercicios_vetor;

import java.util.Scanner;

//Exercicio 4

public class Principal {
    public static void main(String[] args) {
        Scanner mer = new Scanner(System.in);
        Dobro dobro = new Dobro();

        System.out.print("Coloque quantos números deseja digitar: ");
        int quant = mer.nextInt();

        int[] numeros = new int[quant];

        for (int i = 0; i < quant; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = mer.nextInt();
        }

        int soma = dobro.somatorio(numeros);
        int maior = dobro.maiorNumero(numeros);
        System.out.println("\nResultados:");

        System.out.println("Somatório dos números: " + soma);

        System.out.println("Maior número digitado: " + maior);

        System.out.println("Dobros dos números:");
        for (int num : numeros) {
            System.out.println("Dobro de " + num + " é " + dobro.calcularDobro(num));
        }

        mer.close();
    }
}

class Dobro {

    public int calcularDobro(int numero) {
        return numero * 2;
    }

    public int somatorio(int[] numeros) {
        int soma = 0;
        for (int num : numeros) {
            soma += num;
        }
        return soma;
    }

    public int maiorNumero(int[] numeros) {
        int maior = numeros[0];
        for (int num : numeros) {
            if (num > maior) {
                maior = num;
            }
        }
        return maior;
    }
}



