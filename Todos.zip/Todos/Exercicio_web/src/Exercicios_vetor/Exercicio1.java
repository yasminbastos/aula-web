package Exercicios_vetor;

import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[] args) {
        Scanner nom = new Scanner(System.in);
        int c = 10;
        String nome[] = new String[c];

        for (int i = 0; i < c; i++) {
            System.out.print("Digite o seu nome: ");
            String Nu = nom.next();
            nome[i] = Nu;
        }

        for (int i = 0; i < c; i++) {
            System.out.println(nome[i]);
        }
    }
}
