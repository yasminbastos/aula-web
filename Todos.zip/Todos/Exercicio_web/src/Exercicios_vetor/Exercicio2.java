package Exercicios_vetor;

import java.util.Scanner;

public class Exercicio2 {
    public static void main(String[] args) {
        Scanner fil = new Scanner(System.in);
        int f = 10
                ;

        String filme[] = new String[f];
        int[] ano = new int[f];
        String diretor[] = new String[f];

        for (int i = 0; i < f; i++) {
            System.out.print("Digite o nome do filme ganhador do Oscar: ");
            String nome = fil.nextLine();
            System.out.print("Digite o ano de lançamento do filme: ");
            int lan = fil.nextInt();
            fil.nextLine();
            System.out.print("Digite o nome do diretor do filme: ");
            String diretora = fil.nextLine();

            filme[i] = nome;
            ano[i] = lan;
            diretor[i] = diretora;
        }

        for (int i = 0; i < f; i++) {
            System.out.println("Filme: " + filme[i]);
            System.out.println("Ano de Lançamento: " + ano[i]);
            System.out.println("Diretor(a): " + diretor[i]);
            System.out.println("-----------------------------");
        }
    }
}

