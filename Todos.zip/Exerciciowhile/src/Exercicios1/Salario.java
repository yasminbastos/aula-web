package Exercicios1;

import java.util.Scanner;

public class Salario {
    public static void main(String[] args) {
        Scanner sal = new Scanner(System.in);
        System.out.print("Digite seu salário: ");
        float salario = sal.nextFloat();
        System.out.println("Seu salário é: R$ " + salario + "!");
        System.out.print("Digite o porcentual de reajuste em decimal: ");
        float reajuste = sal.nextFloat();
        float nsal =  (reajuste*salario) + salario;
        System.out.print("Seu novo salário é: R$" + nsal);
    }
}