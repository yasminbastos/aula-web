package ExerciciosWhile;

import java.util.Scanner;

public class Somatorio {
    public static void main(String[] args) {
        Scanner som = new Scanner(System.in);
        int y = 0;
        float Total = 0;
        while (y<5){
            System.out.print("Digite o número: ");
            float N = som.nextFloat();
            Total = Total + N;
            y++;
        }
        System.out.print("A somatória é: "+ Total);
    }
}
