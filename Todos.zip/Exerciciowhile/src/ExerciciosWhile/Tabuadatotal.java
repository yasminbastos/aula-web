package ExerciciosWhile;

public class Tabuadatotal {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            for (int n = 1; n<= 10; n++){
                int Tab = i * n;
                System.out.println(i + "x"+ n+"="+ Tab);
            }
            System.out.println("\n");
        }
    }
}
