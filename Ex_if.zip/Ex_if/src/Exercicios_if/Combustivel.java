package Exercicios_if;

import java.util.Scanner;

public class Combustivel {
    public static void main(String[] args) {
        Scanner com = new Scanner(System.in);
        System.out.print("Digite o preço do litro da gasolina: ");
        Float Gas = com.nextFloat();
        System.out.print("Digite o preço do litro do etanol: ");
        Float Eta = com.nextFloat();
        float vale = Eta/Gas;
        if ( vale < 0.7){
            System.out.print("É melhor abastecer com etanol! ");
        }
        else {
            System.out.print("É melhor abastecer com gasolina!");
        }
    }
}
