package Exercicios_While;

public class Contagem {
    public static void main(String[] args) {
        int a = 0;
        while(a<=100){
            if ( a != 90 ){
                System.out.println(a);
                a ++;
            }
            else{
                System.out.println("Programa finalizado");
                break;
            }
        }
    }
}
