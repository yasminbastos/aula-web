package Exercicios_While;

import java.util.Scanner;

public class Tabuada {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        System.out.print("Digite o número que você deseja saber a tabuada: ");
        int Num = num.nextInt();
        System.out.print("Quantos minutos teve de chamada celular: ");
        int val = num.nextInt();
        int x = 0;
        while (x <= val){
           int Nm = Num * x;
           System.out.println(Num + "x"+ x+"="+ Nm);
           x++;
        }
    }
}
