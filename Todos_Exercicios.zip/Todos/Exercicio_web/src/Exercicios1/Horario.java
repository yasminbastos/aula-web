package Exercicios1;
import java.util.Scanner;

public class Horario {
    public static void main(String[] args) {
        Scanner hor = new Scanner(System.in);
        System.out.print("Digite as horas (Sem os minutos): ");
        int hora = hor.nextInt();
        System.out.print("Digite os minutos:");
        int min = hor.nextInt();
        int totm =  (hora*60)+min;
        System.out.print("O horário em minutos é: " + totm);
    }
}