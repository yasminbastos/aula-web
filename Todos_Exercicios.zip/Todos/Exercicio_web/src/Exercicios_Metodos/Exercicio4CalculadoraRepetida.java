package Exercicios_Metodos;

import java.util.Scanner;

public class Exercicio4CalculadoraRepetida {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean continuar = true;

        System.out.println("Calculadora repetida");

        while (continuar) {
            System.out.print("Digite o primeiro número: ");
            double a = sc.nextDouble();
            System.out.print("Digite o segundo número: ");
            double b = sc.nextDouble();

            System.out.println("Escolha a operação:");
            System.out.println("1 - Soma");
            System.out.println("2 - Subtração");
            System.out.println("3 - Multiplicação");
            System.out.println("4 - Divisão");
            System.out.print("Opção: ");
            int opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Resultado: " + (a + b));
                    break;
                case 2:
                    System.out.println("Resultado: " + (a - b));
                    break;
                case 3:
                    System.out.println("Resultado: " + (a * b));
                    break;
                case 4:
                    if (b != 0) {
                        System.out.println("Resultado: " + (a / b));
                    } else {
                        System.out.println("Erro: divisão por zero.");
                    }
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

            System.out.print("Deseja fazer outra operação? (1 = sim, 0 = não): ");
            int r = sc.nextInt();
            continuar = (r == 1);
        }

        sc.close();
    }
}
