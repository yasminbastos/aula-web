package Exercicios_if;

import java.util.Scanner;

public class Media { public static void main(String[] args) {
    Scanner med = new Scanner(System.in);
    System.out.println("Digite a sua primeira nota: ");
    float N1 = med.nextFloat();
    System.out.println("Digite a sua segunda nota");
    float N2 = med.nextFloat();
    System.out.println("Digite a sua terceira nota");
    float N3 = med.nextFloat();
    float media = (N1+N2+N3)/3;
    if(media>=6){
        System.out.println("Aluno Aprovado! Sua média foi "+media);
    }
    else{
        System.out.println("Aluno Reprovado! Sua média foi "+media);
    }
}
}
