package Exercicios_if;

import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        Scanner mer = new Scanner(System.in);
        System.out.println("Para soma digite (+) ");
        System.out.println("Para subtração digite (-) ");
        System.out.println("Digite o primeiro número: ");
        float Nu1 = mer.nextFloat();
        System.out.println("Digite o segundo número: ");
        float Nu2 = mer.nextFloat();
        System.out.println("Digite o sinal: ");
        String sinal = mer.next();
        if (sinal.equals("+")){
            float resulta = Nu1 + Nu2;
            System.out.println(Nu1+"+"+ Nu2);
            System.out.println("Operação escolhida: soma " + resulta);
        } else if (sinal.equals(("-"))) {
            float resulta = Nu1 - Nu2;
            System.out.println("Operação escolhida: subtração ");
            System.out.println("Resultado: " + resulta);
        } else{
            System.out.println("ERRO");
        }

    }
}
